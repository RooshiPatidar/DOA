﻿namespace RTS
{
    public class Hashtable<T1, T2>
    {
    }
}