﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RTS
{
    public class Church : Building
    {
        static String[] commands = {};

        public Church(Tile x, int y)
            : base(x)
        {

        }

    }
}
